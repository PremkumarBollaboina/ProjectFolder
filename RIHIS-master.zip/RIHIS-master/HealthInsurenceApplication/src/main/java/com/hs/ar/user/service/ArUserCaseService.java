package com.hs.ar.user.service;

import com.hs.ar.user.model.UserCaseMaster;

public interface ArUserCaseService {
	public String registerUser(UserCaseMaster user);

}//ArUserCaseService 
