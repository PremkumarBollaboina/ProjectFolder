package com.hs.util;

public class ArConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String REG_SUCCESS = "Registration is successfull";

	public static final String ERROR = "ERROR";
	public static final String REG_ERROR = "Failed to complete Registration";

}//ARConstants
